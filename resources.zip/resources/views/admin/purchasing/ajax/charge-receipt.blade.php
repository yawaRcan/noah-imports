<div class="row">
    <div class="col-12">
        <img src="{{asset('storage/assets/payment')}}/{{$charge->payment_invoice}}" class="img-fluid" alt="">
    </div>
</div>
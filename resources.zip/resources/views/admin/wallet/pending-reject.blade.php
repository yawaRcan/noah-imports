
    <div class="d-flex justify-content-center align-items-center">
         
          <div>
          <a class="btn btn-light-info text-info font-weight-medium waves-effect approve-wallet"  data-wallet-id="{{$wallet->id}}">Approve</a>
               <button class="btn btn-light-info text-info font-weight-medium waves-effect reject-wallet" data-wallet-id="{{$wallet->id}}">Reject</button>

               <!-- <button class="btn btn-light-info text-info font-weight-medium waves-effect">Pending</button> -->
          </div>
     </div>
    <!-- <div class="col-6">
      </div> -->

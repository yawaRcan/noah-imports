<div class="row">
    <div class="col-12">
        <img src="{{asset('storage/assets/wallet')}}/{{$wallet->payment_receipt}}" class="img-fluid" alt="">
    </div>
</div>
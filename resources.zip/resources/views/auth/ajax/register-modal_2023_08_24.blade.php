<div class="modal-body">
    <p><strong>Dear valued customer:</strong></p>
    <p><br></p>
    <p>If you did not receive your <s>confirmation mail</s> in your inbox, please check your spam folder. If it is not there, please <strong>WhatsApp </strong>or <strong>Call </strong>us and we will Activate your account for you.</p>
    <p><br></p>
    <blockquote>We have received a few complaints that the emails are going to your junk or spam folder, below is a link that you can follow to eliminate that issue:</blockquote>
    <p><br></p>
    <p><a href="https://www.howtogeek.com/290046/how-to-stop-legitimate-emails-from-getting-marked-as-spam" rel="noopener noreferrer" target="_blank">https://www.howtogeek.com/290046/how-to-stop-legitimate-emails-from-getting-marked-as-spam/</a></p>
    <p><br></p>
    <p><strong>Best regards,</strong></p>
    <p><strong>The Managing Director.</strong></p>
</div>
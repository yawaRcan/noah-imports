<div class="row">
    <div class="col-12">
        <img src="{{asset('storage/assets/payment')}}/{{$payment->payment_receipt}}" style="width: 30%;" class="img-fluid mx-auto d-block" alt=""><br><br>

    </div>
   
</div>
 
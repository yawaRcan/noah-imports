<?php

namespace App\Http\Controllers\User;

use App\Models\User;
use App\Models\Admin;
use App\Models\Order;
use App\Models\Parcel;
use App\Models\Wallet;
use GuzzleHttp\Client;
use App\Models\Payment;
use App\Models\Purchase;
use App\Events\OrderEvent;
use App\Models\OrderPayment;
use App\Events\ParcelEvent;
use App\Models\ConfigStatus;
use App\Models\PurchaseCart;
use Illuminate\Http\Request;
use App\Models\EmailTemplate;
use App\Models\PaymentStatus;
use App\Models\ShippingAddress;
use App\Traits\CartCalculation;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Symfony\Component\DomCrawler\Crawler;
use Symfony\Component\HttpClient\HttpClient;
use Symfony\Component\BrowserKit\HttpBrowser;
use Illuminate\Support\Facades\Storage;
use Yajra\DataTables\Facades\DataTables;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
use App\Notifications\UserEmailNotification;
use SimpleSoftwareIO\QrCode\Facades\DNS1DFacade;
use App\Http\Requests\User\Purchase\StoreRequest;
use App\Notifications\ShipmentCreateNotification;
use App\Http\Requests\User\Purchase\UpdateRequest;
use App\Http\Requests\User\PurchaseOrder\StoreOrderRequest;
use App\Http\Requests\User\PurchaseOrder\UpdateOrderRequest;
use App\Http\Requests\User\OrderPayment\UpdatePaymentRequest;
use App\Http\Requests\User\OrderPaymentCharge\StoreChargeRequest;
use App\Http\Requests\User\OrderPaymentCharge\UpdateChargeRequest;

class OrderController extends Controller
{

    use CartCalculation;
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $config = 'all';
        $orderAmountDue = 0;
        $title = 'All Orders';
        $orders = Order::where('user_id',Auth::guard('web')->user()->id)->where('balance_due','>',0)->get();
        foreach($orders as $order){
            $orderAmountDue += str_replace(',','',number_format($order->balance_due * $order->currency->value,2));
        }
        return view('user.purchasing.index', ['title' => $title,'status' => $config, 'orderAmountDue' => $orderAmountDue]);
    }

    public function pendingOrders()
    {
       
        $config = 'pending';
        $title = 'Pending Orders';
        $orderAmountDue = 0;
        $orders = Order::where('user_id',Auth::guard('web')->user()->id)->where('balance_due','>',0)->get();
        foreach($orders as $order){
            $orderAmountDue += str_replace(',','',number_format($order->balance_due * $order->currency->value,2));
        }
        return view('user.purchasing.index', ['title' => $title,'status' => $config, 'orderAmountDue' => $orderAmountDue]);
        
        
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $userId = Auth::user()->id;
        $paymentMethods = Payment::orderBy('name', 'ASC')->get();
        $cartData = PurchaseCart::with('purchase', 'user')->where('user_id', $userId)->get();

        if (count($cartData) > 0) {
            $this->products = Purchase::where(['user_id' => $userId, 'status' => 0])->get();

            if (isset($this->products[0]) && !is_null($this->products)) {
                $serviceFee = $this->serviceChargeFee(true); 
                $cal = (object) $this->calc();
            }

            return view('user.purchasing.create', compact( 'serviceFee', 'cartData',  'paymentMethods','cal'));
        } else {
            return view('user.purchasing.create', compact('paymentMethods'));
        }
    }

    public function calc()
    {
        return [
            'shipping' => $this->getShipping(true),
            'tax' => $this->getTax(true),
            'total' => $this->getSubTotal(true),
            'paypal' =>  $this->paypalFee(true),
            'tenOrderFee' => $this->tenOrderFee(0, 'public',true),
            'adminFee' => $this->adminFee(true),
            'totalConverted' => $this->totalConverted($this->products[0]->currency_id, true),
        ] ;
    }

    public function addToCart(StoreRequest $request)
    {
        $request['user_id'] = Auth::user()->id;
        
        $purchase = Purchase::create($request->all());

        PurchaseCart::create(['user_id' => $purchase->user_id, 'purchase_id' => $purchase->id]);
        $html = $this->getCardData($purchase->user_id);
        $notify = [
            'success' => "Product added to cart successfully.",
            'redirect' => route('user.purchasing.get.cart'),
            'html' => $html,
        ];
        return $notify;
    }


    public function getCardData($userId)
    {
        $cartData = PurchaseCart::with('purchase', 'user')->where('user_id', $userId)->get();
        $this->products = Purchase::where(['user_id' => $userId, 'status' => 0])->get(); 
        $paymentMethods = Payment::orderBy('name', 'ASC')->get();
        if(count($this->products) > 0)
            $cal = (object) $this->calc();
        else
            $cal = null;

        return view('user.purchasing.cart', compact('cartData','paymentMethods','cal'))->render();
    }

    public function editCardData(Request $request)
    {
        $purchase = Purchase::find($request->id);
        return $purchase;
    }


    public function updateCardData(UpdateRequest $request)
    {
        $purchase = Purchase::updateOrCreate(['id' => $request->purchase_id], $request->all());

        $html = $this->getCardData($purchase->user_id);
        $notify = [
            'success' => "Cart data updated successfully.",
            'redirect' => route('user.purchasing.get.cart'),
            'html' => $html,
        ];
        return $notify;
    }


    public function removeFromCart(Request $request)
    {
        if ($request->id) {
            PurchaseCart::where('purchase_id', $request->id)->delete();
            Purchase::find($request->id)->delete();

            $userId = Auth::user()->id;
            $html = $this->getCardData($userId);
            $notify = [
                'success' => "Product removed from cart successfully.",
                'redirect' => route('user.purchasing.get.cart'),
                'html' => $html,
            ];


            return $notify;
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreOrderRequest $request)
    {
        $paymentStatuses = PaymentStatus::all();
        $user = Auth::user();
        $paymentStatusId = $paymentStatuses->where('slug','unpaid')->pluck('id')->first();

        $pendingStatus = ConfigStatus::where('slug', 'pending')->first();
        if ($pendingStatus)
            $deliveryStatusId = $pendingStatus->id;
        else
            $deliveryStatusId = null;

        $id = Order::orderBy('id','desc')->pluck('id')->first();
        if($id)
            $id = $id + 1;
        else
            $id = 1;

        $quantity = Purchase::whereIn('id',$request->purchase_id)->sum('quantity');

        $order = new Order();
        $order->user_id = $request->user_id;
        $order->purchase_id = $request->purchase_id;
        $order->code = substr(str_shuffle(md5(rand(1000, 9999))), 0, 7);
        $order->currency_id = $request->currency_id;
        // $order->payment_id = $request->payment_method_id;
        $order->shipping_address_id = $request->shipping_address_id;
        $order->payment_status_id = $paymentStatusId;
        $order->delivery_status = $deliveryStatusId;
        $order->total_qty = $quantity;
        $order->status = 0;
        $order->insurance_tax = str_replace(',', '', $request->eGaroshiTax);
        $order->discount = ($request->discount) ? 1 : 0;
        $order->shipping_price = $request->shipping_price;
        $order->tax = $request->tax;
        $order->sub_total = str_replace(',', '', $request->subtotal);
        $order->total = str_replace(',', '', $request->total);
        $order->balance_due = str_replace(',', '', $request->total);
        $order->amount_converted = str_replace(',', '', $request->converted_amount);

        $order->invoice = general_setting('setting')->invoice_no . $id;
        $order->awb = general_setting('setting')->waybil_no . $id;
        $order->save();

        $admin = Admin::first(); 

        $user = User::findOrFail($order->user_id);

        $template = EmailTemplate::where('slug', 'new-purchase-order')->first();

        if ($template) {

            $shortCodes = [
                'order_no' => $order->code,
                'order_status' =>  $order->deliveryStatus->name,
                'invoice_url' => route('user.purchasing.order.invoice.print', ['id' => $order->id]),
            ];

            //Send notification to user
            event(new OrderEvent($template, $shortCodes, $order, $admin, 'CreateOrder'));

            //Send notification to user
            event(new OrderEvent($template, $shortCodes, $order, $user, 'CreateOrder'));
        } else {

            $notify = [
                'error' => "Something went wrong contact your admin.",
            ];

            // return $notify;
        }

        $redirect = route('user.purchasing.payment.add',['id' => $order->id]); 

        $notify = ['success' => "Order created successfully.", 'redirect' => $redirect];
        return $notify;
    }

    public function addPayment(string $id)
    {
        $order = Order::findOrFail($id);
        // $paymentMethods = Payment::orderBy('name', 'ASC')->get();
        // $recieverAddresses = $order->user->shipping;
        // return view('user.purchasing.add_payment', compact('order', 'paymentMethods', 'recieverAddresses'));
        return view('user.purchasing.order-payment', compact('order'));
    }

    public function createCharge($id)
    {
        $order = Order::findOrFail($id);
        return view('user.purchasing.ajax.charge-create',compact('order'));
    }

    public function storeCharge(StoreChargeRequest $request)
    {
        $order = Order::findOrFail($request->order_id);
        if($order->balance_due == 0){
            $notify = ['error' => "Payment already completed for this order"];
            return $notify;
        }else{
            $paidAmount = trim($request->paid_amount);
            $paymentMehod = Payment::findOrFail($request->payment_method);

            if ($paidAmount > $order->total) {
                $notify = ['error' => "Paid amount should be less than total amount!"];
                return $notify;
            }

            if ($paymentMehod->slug == "account-funds") {
                $userBalance = $order->user->balance();
                $totalConverted = $order->currency->value * $paidAmount;
                $amount = (float) str_replace(',', '', $totalConverted);

                if ($userBalance <= 0 || $userBalance < $amount) {
                    $notify = ['error' => "Your Account Balance is not enough!"];
                    return $notify;
                }
            }

            $charge = new OrderPayment();
            $charge->order_id = $request->order_id;
            $charge->payment_id = $request->payment_method;
            if (isset($request->payment_receipt)) {
                $charge->payment_invoice = $this->fileUpload($request->payment_receipt, $charge->payment_invoice);
            }
            $charge->paid_amount = $paidAmount;
            $charge->save();

            $order->balance_due = str_replace(',','',number_format($order->balance_due,2)) - $charge->paid_amount;
            if($order->balance_due == 0)
                $order->payment_status_id = 2;

            $order->save();
        }

        

        // if($order->balance_due == 0){
        //     $notify = ['success' => "Order payment completed successfully!", 'redirect' => route('purchasing.order.list')];
        // }
        // else{
            $table = view('user.purchasing.ajax.order-billings', ['order' => $order])->render();

            $html = ['selector' => 'billing-tbody', 'data' => $table];
            $notify = ['success' => "New charge added successfully!", 'html' => $html];
        // }

        
        return $notify;
        
    }

    public function editCharge($id)
    {
        $charge = OrderPayment::findOrFail($id);
        return view('user.purchasing.ajax.charge-edit',compact('charge'));
    }

    public function updateCharge(UpdateChargeRequest $request, string $id)
    {
        $charge = OrderPayment::findOrFail($id);

        $balanceDue = $charge->order->total - $charge->order->billing->where('id','!=',$charge->id)->sum('paid_amount');


        $paidAmount = trim($request->paid_amount);
        $paymentMehod = Payment::findOrFail($request->payment_method);

        if ($paidAmount > $balanceDue) {
            $notify = ['error' => "Paid amount should be less than balance due!"];
            return $notify;
        }

        if ($paymentMehod->slug == "account-funds") {
            $userBalance = $charge->order->user->balance();
            $totalConverted = $charge->order->currency->value * $paidAmount;
            $amount = (float) str_replace(',', '', $totalConverted);

            if ($userBalance <= 0 || $userBalance < $amount) {
                $notify = ['error' => "Your Account Balance is not enough!"];
                return $notify;
            }
        }

        $charge->payment_id = $request->payment_method;
        $charge->paid_amount = $paidAmount;
        $charge->save();


        $charge->order->balance_due = number_format($balanceDue - $charge->paid_amount,2);

        if($charge->order->balance_due == 0)
            $charge->order->payment_status_id = 2;
        else
            $charge->order->payment_status_id = 1;

        $charge->order->save();

        $charge->order->load('billing');

        // if($order->balance_due == 0){
        //     $notify = ['success' => "Order payment completed successfully!", 'redirect' => route('purchasing.order.list')];
        // }
        // else{
            $table = view('user.purchasing.ajax.order-billings', ['order' => $charge->order])->render();

            $html = ['selector' => 'billing-tbody', 'data' => $table];
            $notify = ['success' => "Charge updated successfully!", 'html' => $html];
        // }

        return $notify;
    }

    public function deleteCharge($id)
    {
        $charge = OrderPayment::findOrFail($id);

        $charge->order->balance_due = $charge->order->balance_due + $charge->paid_amount;

        $charge->order->payment_status_id = 1;

        $charge->order->save();

        $charge->delete();

        $charge->order->load('billing');

        // if($order->balance_due == 0){
        //     $notify = ['success' => "Order payment completed successfully!", 'redirect' => route('purchasing.order.list')];
        // }
        // else{
            $table = view('user.purchasing.ajax.order-billings', ['order' => $charge->order])->render();

            $html = ['selector' => 'billing-tbody', 'data' => $table];
            $notify = ['success' => "Charge deleted successfully!", 'html' => $html];
        // }

        return $notify;
    }

    public function createItem()
    {
        $userId = Session::get('user_id');
        $users = User::orderBy('first_name', 'ASC')->get();
        return view('user.purchasing.add-item', compact('users', 'userId'));
    }

    public function getPaymentInfo(string $id)
    {
        $payment = Payment::findOrFail($id);
        $user = Auth::user();
        if($payment->slug == "account-funds"){
            $userBalance = $user->balance();
            if($userBalance < 0){
                $html = "<p><u>Account Info</u></p><p>Wallet Balance: <strong class='text-danger'>ƒ " . $userBalance . " ANG</strong></p><p>Sincerely,</p><p>Noah Imports Courier Team</p>";
            }
            else{
                $html = "<p><u>Account Info</u></p><p>Wallet Balance: <strong>ƒ " . $userBalance . " ANG</strong></p><p>Sincerely,</p><p>Noah Imports Courier Team</p>";
            }
            return $html;
        }
        return $payment->information;
    }

    public function updatePayment(UpdatePaymentRequest $request, string $id)
    {
        $paymentStatusId = PaymentStatus::where('slug','paid')->pluck('id')->first();
        $paymentMethod = Payment::findOrFail($request->payment_method_id);
        $order = Order::findOrFail($id);
        $balanceFlag = 0;
        if($paymentMethod->slug == "account-funds"){
            $userBalance = $order->user->balance();
            $amount = $order->amount_converted;

            if($userBalance < 0 || $userBalance < $amount){
                $notify = ['error' => "Your Account Balance is not enough!"];
                return $notify;
            }else{
                $balanceFlag = 1;
            }
        }
        if (isset($request->payment_receipt)) {
            $order->payment_receipt = $this->fileUpload($request->payment_receipt, $order->payment_receipt);
        }
        $order->payment_id = $request->payment_method_id;
        $order->payment_status_id = $paymentStatusId;
        $order->shipping_address_id = $request->shipping_address_id;
        $order->save();

        if($balanceFlag){
            $wallet = new Wallet();
            $wallet->payment_id = $order->payment_id;
            $wallet->currency_id = $order->currency_id;
            $wallet->type = 'debit';
            $wallet->amount = $order->total;
            $wallet->amount_converted = $order->amount_converted;
            $wallet->description = 'Purchase Order Amount';
            $wallet->status = 'approved';
            $wallet->reason = 'Payment Approved';
            $wallet->morphable()->associate($order->user);
            $wallet->save();
        }
        
        $notify = [
            'success' => "Payment updated successfully.",
            'redirect' => route('user.purchasing.order.list'),
        ];
        return $notify;
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $order = Order::findOrFail($id);
        $purchases = Purchase::whereIn('id', $order->purchase_id)->get();
        $this->products = $purchases;
        $cal = (object) $this->calc();
        $senderAddress = ShippingAddress::whereHasMorph('morphable', [Admin::class])->first();
        return view('user.purchasing.show', ['order' => $order, 'purchases' => $purchases,'cal' => $cal,'senderAddress' => $senderAddress]);
    }

    public function getSiteContent(Request $request)
    {
        $url = $request->site_url;

        $product =  $this->scrapeProductImages($url);
        $title = $product['title'];
        $website = $product['website'];
        $price = $product['price']; 
        $imageUrls = $product['images'];

        if (count($imageUrls) > 0) {

            $html = view('user.purchasing.product_images', compact('imageUrls', 'title', 'website','price'))->render();
            $notify = ['success' => "Product images fetched successfully", 'html' => $html];
        } else {

            $notify = ['error' => "Product images failed to retrieve"];
        }

        return $notify;
    }

    public function scrapeProductImages($url)
    {

        $client = new Client();

        $response = $client->get($url, [
            'headers' => [
                'X-RapidAPI-Host' => 'crawler2.p.rapidapi.com',
                'X-RapidAPI-Key' => 'c28a8bd246msh6aae92b9c2a4b85p123a1fjsn1f581b012c9e',
            ],
        ]);

        $check = $response->getStatusCode();

        if ($check == 200) {
            // Get the HTML content from the response
            $htmlContent = $response->getBody()->getContents();
            // dd($htmlContent);
            // Create a new DOM Crawler instance
            $crawler = new Crawler($htmlContent);

            $imageUrls = array();

            $parts = parse_url($url);

            if (isset($parts['scheme']) && isset($parts['host'])) {

                $mainLink = $parts['scheme'] . "://" . $parts['host'];
            } else {

                return [];
            }

            $matchScores = array();

            similar_text($mainLink, 'https://www.ebay.com', $ebayScore);

            similar_text($mainLink, 'https://www.amazon.com', $amazonScore);

            similar_text($mainLink, 'https://www.walmart.com', $walmartScore);

            similar_text($mainLink, 'https://www.alibaba.com', $alibabaScore);

            similar_text($mainLink, 'https://sale.alibaba.com/', $alibabasaleScore);

            similar_text($mainLink, $mainLink, $normalScore);


            $matchScores['ebayStr'] = $ebayScore;

            $matchScores['amazonStr'] = $amazonScore;

            $matchScores['walmartStr'] = $walmartScore;

            $matchScores['alibabaStr'] = $alibabaScore;

            $matchScores['alibabasaleStr'] = $alibabasaleScore;

            $matchScores['normalStr'] = $normalScore;

            arsort($matchScores); // Sort the match scores in descending order

            $mostMatchedString = key($matchScores); // Get the key (string) with the highest match score

            if ($mostMatchedString === 'ebayStr') {

                $imageUrls = $this->extractEbay($url);
            } elseif ($mostMatchedString === 'amazonStr') {

                $imageUrls = $this->extractAmazon($url);
            } elseif ($mostMatchedString === 'walmartStr') {

                $imageUrls = $this->extractWalMart($url);
            } elseif ($mostMatchedString === 'alibabaStr') {

                $imageUrls = $this->extractAliBaba($url);
            } elseif ($mostMatchedString === 'alibabasaleStr') {

                $imageUrls = $this->extractAliBabaSale($url);
            } elseif ($mostMatchedString === 'normalStr') {

                if (!$imageUrls) {

                    $imageUrls = $this->extractfigure($url);

                    if (!$imageUrls) {

                        $imageUrls = $this->extractList($url);

                        if (!$imageUrls) {

                            $imageUrls = $this->extractDivImg($url);

                            if (!$imageUrls) {

                                $imageUrls = $this->extractOG($url);

                                if (!$imageUrls) {

                                    $imageUrls = $this->extractAS($url);

                                    if (!$imageUrls) {

                                        $imageUrls = [];
                                    }
                                }
                            }
                        }
                    }
                }
            } else {

                return [];
            }

            return $imageUrls;
        }
    }

    function extractOG($url)
    {
        $client = new  \Goutte\Client();

        $parsedUrl = parse_url($url);

        $host = $parsedUrl['host'];

        $domainParts = explode('.', $host);

        $domain = $domainParts[count($domainParts) - 2];

        $imageUrls['website'] = $domain;

        $crawler = $client->request('GET', $url);

        $imageUrls['title'] = 'Default';
        // Use CSS selectors to find the product image elements
        $imageElements = $crawler->filter('meta[property="og:image"]');

        $imageUrls = [];
        // Extract the image URLs
        $imageElements->each(function (Crawler $element) use (&$imageUrls) {

            $imageUrl = $element->attr('content');

            $imageUrls['images'][] = $imageUrl;
        });

        return $imageUrls;
    }

    function extractAS($url)
    {
        $client = new  \Goutte\Client();

        $parsedUrl = parse_url($url);

        $host = $parsedUrl['host'];

        $domainParts = explode('.', $host);

        $domain = $domainParts[count($domainParts) - 2];

        $imageUrls['website'] = $domain;

        $crawler = $client->request('GET', $url);

        $imageUrls['title'] = 'Default';
        // Use CSS selectors to find the product image elements
        $imageElements = $crawler->filter('link[as="image"]');

        $imageUrls = [];
        // Extract the image URLs
        $imageElements->each(function (Crawler $element) use (&$imageUrls) {

            $imageUrl = $element->attr('href');

            $imageUrls['images'][] = $imageUrl;
        });

        return $imageUrls;
    }

    function extractList($url)
    {
        $client = new  \Goutte\Client();

        $parsedUrl = parse_url($url);

        $host = $parsedUrl['host'];

        $domainParts = explode('.', $host);

        $domain = $domainParts[count($domainParts) - 2];

        $imageUrls['website'] = $domain;

        $crawler = $client->request('GET', $url);

        $imageUrls['title'] = 'Default';
        // Use CSS selectors to find the product image elements
        $imageElements = $crawler->filter('li a img');

        $imageUrls = [];
        // Extract the image URLs
        $imageElements->each(function (Crawler $element) use (&$imageUrls) {

            $imageUrl = $element->attr('data-original');

            if (filter_var($imageUrl, FILTER_VALIDATE_URL)) {
            } else {

                $imageUrl = $element->attr('data-src');

                if (filter_var($imageUrl, FILTER_VALIDATE_URL)) {
                } else {
                    $imageUrl = $element->attr('src');
                }
            }

            $imageUrls['images'][] = $imageUrl;
        });

        return $imageUrls;
    }

    function extractfigure($url)
    {
        $client = new  \Goutte\Client();

        $parsedUrl = parse_url($url);

        $host = $parsedUrl['host'];

        $domainParts = explode('.', $host);

        $domain = $domainParts[count($domainParts) - 2];

        $imageUrls['website'] = $domain;

        $crawler = $client->request('GET', $url);

        $imageUrls['title'] = 'Default';
        // Use CSS selectors to find the product image elements
        $imageElements = $crawler->filter('figure img');
        // Extract the image URLs
        $imageElements->each(function (Crawler $element) use (&$imageUrls) {

            $imageUrl = $element->attr('data-original');

            if (filter_var($imageUrl, FILTER_VALIDATE_URL)) {
            } else {

                $imageUrl = $element->attr('data-src');

                if (filter_var($imageUrl, FILTER_VALIDATE_URL)) {
                } else {
                    $imageUrl = $element->attr('src');
                }
            }

            $imageUrls['images'][] = $imageUrl;
        });

        return $imageUrls;
    }

    function extractDivImg($url)
    {
        $client = new  \Goutte\Client();

        $parsedUrl = parse_url($url);

        $host = $parsedUrl['host'];

        $domainParts = explode('.', $host);

        $domain = $domainParts[count($domainParts) - 2];

        $imageUrls['website'] = $domain;

        $crawler = $client->request('GET', $url);

        $imageUrls['title'] = 'Default';
        // Use CSS selectors to find the product image elements
        $imageElements = $crawler->filter('div img');

        $imageUrls = [];
        // Extract the image URLs
        $imageElements->each(function (Crawler $element) use (&$imageUrls) {

            $imageUrl = $element->attr('srcset');

            $links = explode(",", $imageUrl);

            foreach ($links as $link) {

                if ($link != "" && $link != null) {

                    $links = explode(" ", $link);

                    if ($links[0] != "" && $links[0] != null) {

                        $imageUrls['images'][] = $links[0];
                    }
                }
            }
        });

        return $imageUrls;
    }

    function extractEbay($url)
    {
        $client = new  \Goutte\Client();

        $parsedUrl = parse_url($url);

        $host = $parsedUrl['host'];

        $domainParts = explode('.', $host);

        $domain = $domainParts[count($domainParts) - 2];

        $imageUrls['website'] = $domain;

        $crawler = $client->request('GET', $url);

        $title = $crawler->filter('.x-item-title h1 span')->first();

        $imageUrls['title'] = $title->text();

        $price = $crawler->filter('.x-price-primary .ux-textspans')->first();
        $string = "US $349.00";
        $pattern = '/\d+(\.\d+)?/';  // Regular expression pattern to match the price 
        preg_match($pattern, $price->text(), $matches); 
        if (!empty($matches)) {
            $price = $matches[0];
            $imageUrls['price'] = $price;  // Output: 349.00
        }else{
            $imageUrls['price'] = 0;
        }
        

        // Use CSS selectors to find the product image elements
        $imageElements = $crawler->filter('.ux-image-filmstrip-carousel-item');

        // Extract the image URLs
        $imageElements->each(function (Crawler $element) use (&$imageUrls) {

            $element = $element->filter('img');
            $imageUrl = $element->attr('src');

            $imageUrls['images'][] = $imageUrl;
        });

        return $imageUrls;
    }

    function extractAliBaba($url)
    {
        $client = new  \Goutte\Client();

        $parsedUrl = parse_url($url);

        $host = $parsedUrl['host'];

        $domainParts = explode('.', $host);

        $domain = $domainParts[count($domainParts) - 2];

        $imageUrls['website'] = $domain;

        $crawler = $client->request('GET', $url);

        $title = $crawler->filter('.product-title h1')->first();

        $imageUrls['title'] = $title->text();

        $price = $crawler->filter('.price-item .price .promotion')->first(); 
        $pattern = '/\d+(\.\d+)?/';  // Regular expression pattern to match the price 
        preg_match($pattern, $price->text(), $matches); 
        if (!empty($matches)) {
            $price = $matches[0];
            $imageUrls['price'] = $price;  // Output: 349.00
        }else{
            $imageUrls['price'] = 0;
        }
        

        // Use CSS selectors to find the product image elements
        $imageElements = $crawler->filter('.detail-next-slick-slide img');

        // Extract the image URLs
        $imageElements->each(function (Crawler $element) use (&$imageUrls) {


            $imageUrl = $element->attr('src');

            $imageUrls['images'][] = $imageUrl;
        });

        return $imageUrls;
    }

    function extractAliBabaSale($url)
    {
        $client = new  \Goutte\Client();

        $parsedUrl = parse_url($url);

        $host = $parsedUrl['host'];

        $domainParts = explode('.', $host);

        $domain = $domainParts[count($domainParts) - 2];

        $imageUrls['website'] = $domain;

        $crawler = $client->request('GET', $url);

        $title = $crawler->filter('.product-title h1')->first();

        $imageUrls['title'] = $title->text();

        // Use CSS selectors to find the product image elements
        $imageElements = $crawler->filter('.detail-next-slick-slide img');

        // Extract the image URLs
        $imageElements->each(function (Crawler $element) use (&$imageUrls) {


            $imageUrl = $element->attr('src');

            $imageUrls['images'][] = $imageUrl;
        });

        return $imageUrls;
    }

    function extractAmazon($url)
    {

        $client = new  \Goutte\Client();

        $parsedUrl = parse_url($url);

        $host = $parsedUrl['host'];

        $domainParts = explode('.', $host);

        $domain = $domainParts[count($domainParts) - 2];

        $imageUrls['website'] = $domain;

        $crawler = $client->request('GET', $url);

        $title = $crawler->filter('#productTitle')->first();

        $imageUrls['title'] = $title->text();

        $imageElements = $crawler->filter('span span span img');

        $imageElements->each(function (Crawler $element) use (&$imageUrls) {

            // $element = $element->filter('img');
            $imageUrl = $element->attr('src');

            $extension = pathinfo($imageUrl, PATHINFO_EXTENSION);

            if (in_array($extension, ['jpeg', 'jpg', 'png', 'webp'])) {
                $imageUrls['images'][] = $imageUrl;
            }
        });

        return $imageUrls;
    }

    function extractWalMart($url)
    {
        // Create a custom HttpClient instance with the desired headers
        $httpClient = HttpClient::create([
            'headers' => [
                'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36',
            ],
        ]);

        $client = new HttpBrowser($httpClient);

        // $client = new  \Goutte\Client($httpClient);

        $parsedUrl = parse_url($url);

        $host = $parsedUrl['host'];

        $domainParts = explode('.', $host);

        $domain = $domainParts[count($domainParts) - 2];

        $imageUrls['website'] = $domain;

        $client->request('GET', $url);

        $crawler = $client->getResponse()->getContent();

        // $title = $crawler->filter('#productTitle');

        $imageUrls['title'] = 'WalMart';

        // $imageElements = $crawler->filter('img');

        // $imageElements->each(function (Crawler $element) use (&$imageUrls) {

        //     // $element = $element->filter('img');
        //     $imageUrl = $element->attr('src');

        //     $extension = pathinfo($imageUrl, PATHINFO_EXTENSION);

        //     if (in_array($extension, ['jpeg', 'jpg', 'png', 'webp'])) {
        //         $imageUrls['images'][] = $imageUrl;
        //     }
        // });
        // if(!isset($imageUrls['images'])){
        $imageUrls['images'][] = 'https://www.google.com/recaptcha/about/images/reCAPTCHA-logo@2x.png';
        // }

        return $imageUrls;
    }

    public function fileUpload($file, $oldFile = null)
    {
        if (isset($file)) {
            $fileFormats = ['image/jpeg', 'image/png', 'image/gif', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/pdf', 'text/plain'];
            if (!in_array($file->getClientMimeType(), $fileFormats)) {
                // return Reply::error('This file format not allowed');
            }
            if (Storage::exists('assets/payment/' . $oldFile)) {
                Storage::Delete('assets/payment/' . $oldFile);
                $file->storeAs('assets/payment/', $file->hashName());
                return $file->hashName();
                /* 
                  Storage::delete(['upload/test.png', 'upload/test2.png']);
                */
            } else {
                $file->storeAs('assets/payment/', $file->hashName());
                return $file->hashName();
            }
        } else {
            return $oldFile;
        }
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

    public function getPaymentHtml($id)
    {
        $payment = Order::select('id','payment_receipt')->where('id', $id)->first();
        return view('user.purchasing.payment', ['payment' => $payment]);
    }

    public function getChargePaymentHtml($id)
    {
        $charge = OrderPayment::select('id','payment_invoice')->where('id', $id)->first();
        return view('user.purchasing.ajax.charge-receipt', compact('charge'));
    }


    public function printInvoice($id)
    {
        $order = Order::findOrFail($id);
        $purchases = Purchase::whereIn('id', $order->purchase_id)->get();
        $this->products = $purchases;
        $cal = (object) $this->calc();
        $barcode = $this->generateQRcode(route('user.purchasing.order.invoice.print', ['id' => $order->id]));
        return view('user.purchasing.print_invoice', compact('order', 'purchases', 'barcode','cal'));
    }

    public function generateQRcode($data = null, $barcodeType = null)
    {

        $QRData = QrCode::generate($data);;

        return $QRData;
    }


    public function data(Request $request)
    {
        
        if (isset($request->status) && $request->status != '' && $request->status != null) {
            $data =  Order::where('user_id',Auth::user()->id);
            if($request->status=='pending'){
                $data->where('status', 0);
            }else{

                $data->where('status', $request->status);
            }
            $data=$data->get();
        } else {
            $data = Order::where('user_id',Auth::user()->id)->get();
        }

        return Datatables::of($data)
            ->addIndexColumn()
            ->addColumn('action', function ($row) {
                $actionBtn = '<div class="dropdown dropstart">
                    <a href="#" class="link" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-horizontal feather-sm">
                            <circle cx="12" cy="12" r="1"></circle>
                            <circle cx="19" cy="12" r="1"></circle>print
                            <circle cx="5" cy="12" r="1"></circle>
                        </svg>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton" style="margin: 0px;">
                        <li><a class="dropdown-item order-data-view" href="' . route('user.purchasing.order.show', ['id' => $row->id]) . '">View</a></li>
                        <li><a class="dropdown-item order-data-invoice" href="' . route('user.purchasing.payment.add', ['id' => $row->id]) . '" target="_blank">Upload Payment</a></li>
                        <li><a class="dropdown-item order-data-invoice" href="' . route('user.purchasing.order.invoice.print', ['id' => $row->id]) . '" target="_blank">Print Invoice</a></li>
                    </ul>
                </div>';
                return $actionBtn;
            })
            ->addColumn('delivery_status', function ($row) {
                $html = $row->deliveryStatus->name ?? 'N/A';
                if (isset($row->deliveryStatus->color)) {
                    $html = '<span class="mb-1 badge" style="background-color:' . $row->deliveryStatus->color . '">' . $row->deliveryStatus->name . '</span>';
                }
                return $html;
            })
            ->addColumn('status', function ($row) {

                if ($row->status == 0) {
                    $html = '<span class="mb-1 badge bg-danger">Pending</span>';
                } else {
                    $html = '<span class="mb-1 badge bg-success">Active</span>';
                }

                return $html;
            })
            ->addColumn('payment_status', function ($row) {
                if ($row->paymentStatus->slug == 'paid') {
                    $html = '<span class="mb-1 badge bg-success">' . $row->paymentStatus->name . '</span>';
                } else {
                    $html = '<a href="' . route('user.purchasing.payment.add', ['id' => $row->id]) . '" target="_blank"><span class="mb-1 badge bg-danger" data-order-id="' . $row->id . '">Unpaid</span></a>';
                }
                return $html;
            })
            ->addColumn('total', function ($row) {

                return (isset($row->total) ? 'ƒ '.number_format($row->amount_converted, 2).' ANG' : 'ƒ 0.00 ANG');
            })
            ->addColumn('reciever', function ($row) {
                $address = 'N/A';
                if(isset($row->shipperAddress)){
                    $address = $row->shipperAddress->first_name.' '.$row->shipperAddress->last_name . ' - ' . $row->shipperAddress->country->name;
                }

                return $address;
            })
            ->addColumn('created_at', function ($row) {
                return (isset($row->created_at) ? $row->created_at->format('F j, Y h:i A') : 'N/A');
            })
            ->rawColumns(['action', 'status', 'delivery_status', 'payment_status', 'total', 'reciever'])
            ->make(true);
    } 
}

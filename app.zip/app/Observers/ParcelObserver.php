<?php

namespace App\Observers;

class ParcelObserver
{
    //
}
